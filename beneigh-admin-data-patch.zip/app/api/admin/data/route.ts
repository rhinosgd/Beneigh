import { ensureCatalog } from "../../../../lib/catalog";
import { sameOrigin } from "../../../../lib/conversations";
import { and, desc, eq, like, or } from "drizzle-orm";
import { getDb } from "../../../../db";
import {
  availability,
  bookings,
  inquiries,
  services,
  siteContent,
} from "../../../../db/schema";
import { getAdminRole, isAdmin } from "../../../../lib/admin-auth";
export async function GET(request: Request) {
  if (
    !(await isAdmin(request)) ||
    (request.method !== "GET" && !sameOrigin(request))
  )
    return Response.json({ error: "Unauthorized" }, { status: 401 });
  await ensureCatalog();
  const u = new URL(request.url),
    q = u.searchParams.get("q") || "",
    status = u.searchParams.get("status") || "";
  const db = getDb();
  let rows = await db.select().from(bookings).orderBy(desc(bookings.createdAt));
  if (q)
    rows = rows.filter((r) =>
      [r.name, r.phone, r.services, r.reference].some((v) =>
        v.toLowerCase().includes(q.toLowerCase()),
      ),
    );
  if (status) rows = rows.filter((r) => r.status === status);
  const [inquiryRows, serviceRows, slotRows, contentRows] = await Promise.all([
    db.select().from(inquiries).orderBy(desc(inquiries.createdAt)),
    db.select().from(services).orderBy(services.sortOrder),
    db.select().from(availability),
    db.select().from(siteContent),
  ]);
  return Response.json({
    role: await getAdminRole(request),
    bookings: rows,
    inquiries: inquiryRows,
    services: serviceRows.filter(
      (x) =>
        !["review", "coordination", "travel", "interpreter"].includes(x.id),
    ),
    availability: slotRows,
    content: Object.fromEntries(contentRows.map((x) => [x.key, x.value])),
  });
}
export async function PATCH(request: Request) {
  if (
    !(await isAdmin(request)) ||
    (request.method !== "GET" && !sameOrigin(request))
  )
    return Response.json({ error: "Unauthorized" }, { status: 401 });
  const data = (await request.json()) as Record<string, unknown>,
    db = getDb();
  if (
    (await getAdminRole(request)) === "staff" &&
    !["booking", "inquiry"].includes(String(data.type))
  )
    return Response.json(
      { error: "Only owners can manage website settings" },
      { status: 403 },
    );
  if (
    data.type === "booking" &&
    !["pending", "confirmed", "cancelled"].includes(String(data.status))
  )
    return Response.json({ error: "Invalid status" }, { status: 400 });
  if (data.type === "booking")
    await db
      .update(bookings)
      .set({ status: String(data.status) })
      .where(eq(bookings.id, Number(data.id)));
  if (data.type === "inquiry")
    await db
      .update(inquiries)
      .set({ status: String(data.status) })
      .where(eq(inquiries.id, Number(data.id)));
  if (
    data.type === "availability" &&
    (!/^\d{4}-\d{2}-\d{2}$/.test(String(data.date)) ||
      !["*", "09:00–12:00", "13:00–17:00", "18:00–21:00"].includes(
        String(data.timeSlot),
      ) ||
      !Number.isInteger(Number(data.capacity)) ||
      Number(data.capacity) < 0)
  )
    return Response.json({ error: "Invalid capacity rule" }, { status: 400 });
  if (data.type === "availability")
    await db.insert(availability).values({
      date: String(data.date),
      timeSlot: String(data.timeSlot),
      capacity: Number(data.capacity) || 0,
      closed: Boolean(data.closed),
    });
  if (data.type === "service") {
    const item = data.item as Record<string, unknown>;
    if (
      !/^[a-z0-9_-]{1,80}$/.test(String(item.id)) ||
      !String(item.nameEn || "").trim() ||
      !Number.isInteger(Number(item.price)) ||
      Number(item.price) < 0
    )
      return Response.json(
        { error: "Invalid service name or price" },
        { status: 400 },
      );
    await db
      .insert(services)
      .values({
        id: String(item.id),
        nameEn: String(item.nameEn),
        nameZh: String(item.nameZh),
        descriptionEn: String(item.descriptionEn || ""),
        descriptionZh: String(item.descriptionZh || ""),
        price: Number(item.price) || 0,
        active: item.active !== false,
        imageUrl: String(item.imageUrl || ""),
        sortOrder: Number(item.sortOrder) || 0,
      })
      .onConflictDoUpdate({
        target: services.id,
        set: {
          nameEn: String(item.nameEn),
          nameZh: String(item.nameZh),
          descriptionEn: String(item.descriptionEn || ""),
          descriptionZh: String(item.descriptionZh || ""),
          price: Number(item.price) || 0,
          active: item.active !== false,
          imageUrl: String(item.imageUrl || ""),
          sortOrder: Number(item.sortOrder) || 0,
        },
      });
  }
  if (data.type === "content")
    await db
      .insert(siteContent)
      .values({ key: String(data.key), value: String(data.value) })
      .onConflictDoUpdate({
        target: siteContent.key,
        set: { value: String(data.value), updatedAt: new Date().toISOString() },
      });
  if (data.type === "contentBatch") {
    const values = data.values as Record<string, unknown>;
    for (const [key, value] of Object.entries(values || {}))
      await db
        .insert(siteContent)
        .values({ key, value: String(value) })
        .onConflictDoUpdate({
          target: siteContent.key,
          set: { value: String(value), updatedAt: new Date().toISOString() },
        });
  }
  return Response.json({ ok: true });
}
export async function DELETE(request: Request) {
  if ((await getAdminRole(request)) !== "owner")
    return Response.json(
      { error: "Owner permission required" },
      { status: 403 },
    );
  if (
    !(await isAdmin(request)) ||
    (request.method !== "GET" && !sameOrigin(request))
  )
    return Response.json({ error: "Unauthorized" }, { status: 401 });
  const data = (await request.json()) as Record<string, unknown>;
  if (data.type === "service")
    await getDb()
      .delete(services)
      .where(eq(services.id, String(data.id)));
  return Response.json({ ok: true });
}
