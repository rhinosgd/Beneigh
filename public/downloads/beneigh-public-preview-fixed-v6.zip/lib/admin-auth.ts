import { env } from "cloudflare:workers";
const bytes = (value: string) => new TextEncoder().encode(value);
async function signature(value: string) {
  if (!env.SESSION_SECRET)
    throw new Error("Admin session secret is unavailable");
  const key = await crypto.subtle.importKey(
    "raw",
    bytes(String(env.SESSION_SECRET)),
    { name: "HMAC", hash: "SHA-256" },
    false,
    ["sign"],
  );
  return Array.from(
    new Uint8Array(await crypto.subtle.sign("HMAC", key, bytes(value))),
  )
    .map((x) => x.toString(16).padStart(2, "0"))
    .join("");
}
export async function sessionToken(role: "owner" | "staff" = "owner") {
  const expiry = String(Date.now() + 1800000),
    nonce = crypto.randomUUID(),
    payload = `${expiry}.${nonce}.${role}`;
  return `${payload}.${await signature(payload)}`;
}
export async function getAdminRole(request: Request) {
  try {
    const token = (request.headers.get("cookie") || "")
      .split(";")
      .map((x) => x.trim())
      .find((x) => x.startsWith("tcd_admin="))
      ?.slice(10);
    if (!token) return null;
    const [expiry, nonce, role, mac] = token.split(".");
    if (
      !["owner", "staff"].includes(role) ||
      !nonce ||
      !/^[a-f0-9]{64}$/.test(mac || "") ||
      !Number.isFinite(Number(expiry)) ||
      Number(expiry) <= Date.now() ||
      Number(expiry) > Date.now() + 1800000
    )
      return null;
    const expected = await signature(`${expiry}.${nonce}.${role}`);
    let mismatch = 0;
    for (let i = 0; i < 64; i++)
      mismatch |= expected.charCodeAt(i) ^ mac.charCodeAt(i);
    return mismatch === 0 ? (role as "owner" | "staff") : null;
  } catch {
    return null;
  }
}

export async function isAdmin(request: Request) {
  return !!(await getAdminRole(request));
}
