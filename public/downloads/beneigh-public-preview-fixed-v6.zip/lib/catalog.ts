import { env } from "cloudflare:workers";
import { defaultPlans } from "./plans";
// A one-time requested catalog replacement. Subsequent administrator edits are preserved.
export async function ensureCatalog() {
  const done = await env.DB.prepare(
    "SELECT value FROM site_content WHERE key = ?",
  )
    .bind("plans_catalog_20260914")
    .first();
  if (done) return;
  await env.DB.batch([
    env.DB.prepare(
      "UPDATE services SET active = 0 WHERE id IN ('review','coordination','travel','interpreter')",
    ),
    ...defaultPlans.map((p) =>
      env.DB.prepare(
        "INSERT INTO services (id,name_en,name_zh,description_en,description_zh,price,active,image_url,sort_order) VALUES (?,?,?,?,?,?,1,'',?) ON CONFLICT(id) DO NOTHING",
      ).bind(
        p.id,
        p.nameEn,
        p.nameZh,
        p.descriptionEn,
        p.descriptionZh,
        p.price,
        p.sortOrder,
      ),
    ),
    env.DB.prepare(
      "INSERT INTO site_content (key,value) VALUES (?,?) ON CONFLICT(key) DO NOTHING",
    ).bind("plans_catalog_20260914", "1"),
  ]);
}
