export const defaultPlans = [
  {
    id: "implants",
    nameEn: "Dental Implants",
    nameZh: "种植牙",
    descriptionEn:
      "Record review and coordination for single-tooth, multiple-tooth or full-arch implant care.",
    descriptionZh: "单颗、多颗或全口种植的资料审核及治疗协调。",
    price: 599,
    active: true,
    imageUrl: "",
    sortOrder: 1,
  },
  {
    id: "general",
    nameEn: "General Dentistry",
    nameZh: "普通牙科",
    descriptionEn:
      "Coordinate dental examinations, preventive care and restorative appointments.",
    descriptionZh: "口腔检查、预防护理及修复预约协调。",
    price: 599,
    active: true,
    imageUrl: "",
    sortOrder: 2,
  },
  {
    id: "cosmetic",
    nameEn: "Cosmetic Dentistry",
    nameZh: "牙科美容",
    descriptionEn:
      "Plan a dentist-led consultation for tooth color, shape and smile aesthetics.",
    descriptionZh: "牙齿颜色、形态及笑容美学咨询协调。",
    price: 599,
    active: true,
    imageUrl: "",
    sortOrder: 3,
  },
  {
    id: "customized",
    nameEn: "Customized",
    nameZh: "定制服务",
    descriptionEn:
      "A tailored coordination package for your treatment goals and travel needs.",
    descriptionZh: "按照治疗目标与行程需求定制协调服务。",
    price: 599,
    active: true,
    imageUrl: "",
    sortOrder: 4,
  },
];
