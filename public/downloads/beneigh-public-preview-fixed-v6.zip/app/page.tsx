"use client";

import Image from "next/image";
import {
  cloneElement,
  isValidElement,
  useEffect,
  useId,
  useState,
} from "react";
import {
  ArrowRight,
  CalendarDays,
  Check,
  ChevronDown,
  CircleDollarSign,
  Clock3,
  HeartHandshake,
  Languages,
  Plane,
  ShieldCheck,
  Stethoscope,
  UserRoundCheck,
  MapPin,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { defaultPlans } from "../lib/plans";
import { preferredLanguage, primaryCopy } from "../lib/languages";
import { QuickContact } from "./components/quick-contact";
import { RichContent } from "./components/rich-content";
import { ContactForm } from "./components/contact-form";
import { SiteFooter } from "./components/site-footer";
import { SiteHeader, type SiteLang } from "./components/site-header";

type Lang = SiteLang;
type PublicService = {
  id: string;
  nameEn: string;
  nameZh: string;
  descriptionEn: string;
  descriptionZh: string;
  price: number;
  active: boolean;
  imageUrl: string;
  sortOrder: number;
};
type SiteConfig = {
  configured?: boolean;
  services: PublicService[];
  content: Record<string, string>;
};
type ManagedItem = {
  id?: string;
  titleEn?: string;
  titleZh?: string;
  textEn?: string;
  textZh?: string;
  date?: string;
  active?: boolean;
  sortOrder?: number;
};
function parseList(value: string | undefined, fallback: ManagedItem[]): ManagedItem[] {
  try {
    const parsed = JSON.parse(value || "");
    return Array.isArray(parsed) ? parsed : fallback;
  } catch {
    return fallback;
  }
}
const copy = {
  en: {
    nav: ["About", "Services", "How It Works", "Contact Us"],
    cta: "Choose Your Plans",
    eyebrow: "Dental treatment support in China",
    titleA: "Restore your smile.",
    titleB: "We coordinate the journey.",
    intro:
      "From record review and clinic matching to appointments, translation and local support — one bilingual team keeps every step clear.",
    trust: [
      "No-obligation initial review",
      "Bilingual care coordination",
      "Plan before you travel",
    ],
    servicesTitle: "One team, from first scan to flight home",
    servicesIntro:
      "Choose only the support you need. Clinical decisions remain between you and your licensed dentist.",
    stepsTitle: "A clearer route to dental care in China",
    whyTitle: "Why patients consider China",
    whyIntro:
      "Modern urban dental centers, broad treatment capability and coordinated scheduling can make complex restorative care easier to plan. Your final suitability and quote always depend on a dentist's review.",
    formTitle: "Request Your Booking",
    formIntro:
      "Tell us what you need. We will review the request and contact you before any paid service is arranged.",
    faqTitle: "Questions before you travel",
  },
  zh: {
    nav: ["关于我们", "服务项目", "服务流程", "联系我们"],
    cta: "选择服务方案",
    eyebrow: "外国人赴华牙科治疗协调服务",
    titleA: "重拾自信笑容，",
    titleB: "我们协调赴华全程。",
    intro:
      "从病历预审、诊所匹配，到预约、翻译和在华协助，由一个双语团队把每一步讲清楚、安排好。",
    trust: ["先审核治疗资料", "中英双语协调", "出发前确认方案"],
    servicesTitle: "从第一份牙片到返程，全程有人协调",
    servicesIntro: "只选择您需要的服务；所有临床决定均由您与持证牙医共同作出。",
    stepsTitle: "更清晰的赴华牙科治疗路径",
    whyTitle: "为什么考虑到中国看牙",
    whyIntro:
      "中国主要城市拥有现代化牙科中心、较完整的治疗能力与灵活排期。是否适合、需要多久以及最终费用，均须由牙医审核资料后确认。",
    formTitle: "提交预约申请",
    formIntro:
      "告诉我们您的需求。任何付费服务安排前，我们会先审核并联系您确认。",
    faqTitle: "出发前常见问题",
  },
};
const defaultFlow = [
  [
    Stethoscope,
    "Dental Plan Review",
    "牙科方案预审",
    "We organize your scans and history for a dentist's review before travel.",
    "整理牙片与病史，出发前提交牙医预审。",
  ],
  [
    UserRoundCheck,
    "Clinic & Dentist Matching",
    "诊所与牙医匹配",
    "Match treatment needs, city, timing and budget with suitable providers.",
    "结合治疗需求、城市、时间与预算匹配合适机构。",
  ],
  [
    CalendarDays,
    "Appointments & Scheduling",
    "预约与排期",
    "Coordinate consultations, procedures and follow-up visits into one itinerary.",
    "把初诊、治疗和复诊安排进一份清晰行程。",
  ],
  [
    Languages,
    "Bilingual Assistance",
    "双语陪诊与翻译",
    "Support communication during consultations, consent and aftercare instructions.",
    "协助问诊、知情沟通与术后注意事项翻译。",
  ],
  [
    Plane,
    "Arrival & Stay Support",
    "接机与住宿协助",
    "Optional airport transfer and accommodation coordination near the clinic.",
    "可选接机及诊所附近住宿协调。",
  ],
  [
    HeartHandshake,
    "Aftercare Coordination",
    "回国后复诊协调",
    "Help organize translated records and remote follow-up questions.",
    "整理翻译后的资料并协助远程复诊问题。",
  ],
] as const;
const faqs = [
  [
    "Can I get an exact price before I travel?",
    "我能在出发前拿到准确报价吗？",
    "A preliminary range may be possible after reviewing scans and records. The final plan and fee are confirmed only after an in-person examination.",
    "审核牙片和病历后可提供初步范围；最终方案与费用须面诊后确认。",
  ],
  [
    "Which dental records should I send?",
    "需要提交哪些牙科资料？",
    "Recent panoramic X-ray or CBCT, treatment history, medication list, allergy information and clear photos of the problem area are helpful.",
    "建议提供近期全景片或CBCT、治疗史、用药清单、过敏信息及问题区域清晰照片。",
  ],
  [
    "How long should I stay in China?",
    "需要在中国停留多久？",
    "It depends on the procedure and healing stage. Some restorative work can be scheduled in one visit; implants may require staged visits months apart.",
    "取决于治疗项目与愈合周期。部分修复可一次完成；种植牙通常需要分阶段到访。",
  ],
  [
    "Do you provide dental treatment directly?",
    "你们直接提供牙科治疗吗？",
    "No. Be Neigh is a coordination service. Diagnosis and treatment are provided by independently licensed dental professionals.",
    "不直接提供。比邻是协调服务平台，诊断与治疗由独立持证牙科专业人员提供。",
  ],
];

export default function Home() {
  const [lang, setLang] = useState<Lang>("en"),
    [config, setConfig] = useState<SiteConfig>({ services: [], content: {} });
  useEffect(() => {
    setLang(preferredLanguage());
    fetch("/api/site-config")
      .then(async (r) => {
        if (!r.ok) throw Error("Unavailable");
        return r.json() as Promise<SiteConfig>;
      })
      .then(setConfig)
      .catch(() => {});
  }, []);
  const t = {
      ...copy[lang === "zh" ? "zh" : "en"],
      ...(lang !== "zh" && lang !== "en" ? primaryCopy[lang] : {}),
    },
    zh = lang === "zh",
    special =
      config.content.hero_special_enabled === "true" &&
      !!config.content.hero_special_image,
    heroImage = special
      ? config.content.hero_special_image
      : config.content.hero_default_image || "/dental-hero.png",
    heroLabel = special
      ? zh
        ? config.content.hero_special_label_zh
        : config.content.hero_special_label_en
      : "",
    flowItems = parseList(config.content.service_flow_json, defaultFlow.map(([, en, cn, de, dc], i) => ({ id: String(i + 1), titleEn: en, titleZh: cn, textEn: de, textZh: dc, active: true, sortOrder: i + 1 }))),
    faqItems = parseList(config.content.faq_items_json, faqs.map(([en, cn, de, dc], i) => ({ id: String(i + 1), titleEn: en, titleZh: cn, textEn: de, textZh: dc, active: true, sortOrder: i + 1 }))),
    newsItems = parseList(config.content.news_announcements, []);
  return (
    <main
      className="min-h-screen overflow-x-clip bg-[#f7fbfb] text-[#163533]"
      dir={lang === "ar" ? "rtl" : "ltr"}
    >
      <SiteHeader lang={lang} onLanguageChange={setLang} />

      <section
        id="top"
        className="mx-auto grid max-w-7xl gap-10 px-5 pb-20 pt-32 lg:grid-cols-[.88fr_1.12fr] lg:items-center lg:px-8 lg:pt-40"
      >
        <div className="relative z-10">
          <p className="mb-5 inline-flex items-center gap-2 rounded-full border border-[#badbd8] bg-white px-4 py-2 text-sm font-bold text-[#0f6d68]">
            <span className="size-2 rounded-full bg-[#ec765f]" />
            {heroLabel || t.eyebrow}
          </p>
          <h1 className="max-w-xl text-5xl font-semibold leading-[1.02] tracking-[-.05em] sm:text-6xl lg:text-7xl">
            {t.titleA}
            <span className="font-serif italic text-[#0f6d68]">
              {" "}
              {t.titleB}
            </span>
          </h1>
          <div className="mt-7 max-w-xl text-lg leading-8 text-[#55716f]">
            {config.content.homepage_intro ? (
              <RichContent html={config.content.homepage_intro} />
            ) : (
              t.intro
            )}
          </div>
          <div className="mt-8 flex flex-col gap-3 sm:flex-row">
            <Button
              asChild
              className="h-14 rounded-full bg-[#ec765f] px-7 text-base text-white hover:bg-[#d85e49]"
            >
              <a href="#plan">
                {t.cta}
                <ArrowRight />
              </a>
            </Button>
            <Button
              asChild
              variant="outline"
              className="h-14 rounded-full border-[#b9d6d3] bg-white px-7 text-base"
            >
              <a href="#contact">{zh ? "联系我们" : "Contact Us"}</a>
            </Button>
          </div>
          <div className="mt-8 flex flex-wrap gap-x-5 gap-y-3">
            {t.trust.map((x) => (
              <span
                className="flex items-center gap-2 text-sm font-semibold text-[#466663]"
                key={x}
              >
                <Check className="size-4 text-[#0f8b82]" />
                {x}
              </span>
            ))}
          </div>
        </div>
        <div className="relative">
          <div className="absolute -inset-3 -z-10 rotate-2 rounded-[2.2rem] bg-[#d9efed] sm:-inset-4 sm:rotate-3 sm:rounded-[3rem]" />
          <Image
            priority
            unoptimized
            src={heroImage}
            alt={
              zh
                ? "国际患者在中国牙科诊所咨询"
                : "International patient discussing dental care in China"
            }
            width={1536}
            height={1024}
            className="h-[360px] w-full rounded-[2rem] object-cover shadow-2xl sm:h-[480px] sm:rounded-[2.5rem]"
          />
          <div className="absolute -bottom-6 left-4 right-4 flex items-center justify-between rounded-2xl bg-white/90 p-4 shadow-xl backdrop-blur sm:left-auto sm:w-72">
            <div>
              <b className="block">
                {zh ? "先审核，再出发" : "Review before travel"}
              </b>
              <span className="text-sm text-[#69817f]">
                {zh ? "减少不确定性" : "Fewer unknowns"}
              </span>
            </div>
            <ShieldCheck className="text-[#0f8b82]" />
          </div>
        </div>
      </section>

      <section id="services" className="bg-white py-24">
        <div className="mx-auto max-w-7xl px-5 lg:px-8">
          <SectionHeading
            title={
              zh
                ? "牙科治疗与赴华协调服务"
                : "Dental care options and China visit support"
            }
            text={t.servicesIntro}
          />
          <div className="mt-12 grid gap-6 md:grid-cols-2 lg:grid-cols-3">
            {(config.configured ? config.services : defaultPlans).filter((p) => p.active).map((p) => {
              const href = p.id === "implants" ? "/services/dental-implants" : p.id === "general" ? "/services/general-dentistry" : p.id === "cosmetic" ? "/services/cosmetic-dentistry" : "#plan";
              const image = p.imageUrl || (p.id === "implants" ? "/dental-plan.png" : p.id === "general" ? "/dental-hero.png" : "/arrival-care.png");
              return (
              <a
                href={href}
                key={p.id}
                className="group overflow-hidden rounded-[1.8rem] border border-[#dcebea] bg-white shadow-sm transition hover:-translate-y-1 hover:shadow-xl"
              >
                <Image
                  unoptimized
                  src={image}
                  width={800}
                  height={520}
                  alt={p.nameEn}
                  className="h-52 w-full object-cover"
                />
                <div className="p-6">
                  <h3 className="text-2xl font-bold">{zh ? p.nameZh : p.nameEn}</h3>
                  <p className="mt-3 line-clamp-3 leading-7 text-[#627b79]">
                    {zh ? p.descriptionZh : p.descriptionEn}
                  </p>
                  <span className="mt-5 flex items-center gap-2 font-bold text-[#0f6d68]">
                    {zh ? "查看服务详情" : "View service details"}
                    <ArrowRight size={17} />
                  </span>
                </div>
              </a>)}
            )}
          </div>
          <h3 id="services-flow" className="mt-16 scroll-mt-28 text-3xl font-bold">
            {zh ? "赴华协调服务" : "China visit coordination"}
          </h3>
          <div className="mt-7 grid gap-5 md:grid-cols-2 lg:grid-cols-3">
            {flowItems.filter((x) => x.active !== false).sort((a,b) => Number(a.sortOrder)-Number(b.sortOrder)).map((item, i) => {
              const Icon = [Stethoscope, UserRoundCheck, CalendarDays, Languages, Plane, HeartHandshake][i % 6];
              return (
              <article
                key={String(item.id || i)}
                className="group rounded-[1.8rem] border border-[#dcebea] bg-[#fbfefe] p-7 transition hover:-translate-y-1 hover:border-[#9bceca] hover:shadow-xl"
              >
                <div className="flex items-start justify-between">
                  <span className="grid size-12 place-items-center rounded-2xl bg-[#e4f3f1] text-[#0f6d68]">
                    <Icon />
                  </span>
                  <span className="text-sm font-bold text-[#829f9c]">
                    Step {i + 1}
                  </span>
                </div>
                <h4 className="mt-6 text-xl font-bold">{zh ? item.titleZh : item.titleEn}</h4>
                <p className="mt-3 text-base leading-7 text-[#627b79]">
                  {zh ? item.textZh : item.textEn}
                </p>
              </article>
            )})}
          </div>
        </div>
      </section>

      <section id="pricing" className="bg-[#edf7f6] py-24">
        <div className="mx-auto max-w-7xl px-5 lg:px-8">
          <SectionHeading
            title="Service Pricing"
            text={
              zh
                ? "以下为演示协调服务报价，最终治疗内容与临床费用另行确认。"
                : "Demonstration coordination packages. Treatment scope and clinical fees are confirmed separately."
            }
          />
          <div className="mt-12 grid gap-5 md:grid-cols-2">
            {(config.configured ? config.services : defaultPlans)
              .filter((p) => p.active)
              .map((p, i) => (
                <article
                  key={p.id}
                  className={`rounded-[1.8rem] border p-7 ${i === 1 ? "border-[#0f8b82] bg-[#153f3c] text-white shadow-xl" : "border-[#d3e5e3] bg-white"}`}
                >
                  <h3 className="text-2xl font-bold">{p.nameEn}</h3>
                  <p
                    className={`mt-4 min-h-24 text-base leading-7 ${i === 1 ? "text-[#c2d8d5]" : "text-[#627b79]"}`}
                  >
                    {zh ? p.descriptionZh : p.descriptionEn}
                  </p>
                  <p
                    className={`mt-5 text-4xl font-bold ${i === 1 ? "text-[#7ed7cf]" : "text-[#0f6d68]"}`}
                  >
                    ${p.price}
                  </p>
                </article>
              ))}
          </div>
          <Button
            asChild
            className="mt-8 h-13 rounded-full bg-[#ec765f] px-7 text-base text-white"
          >
            <a href="#testimonials">
              {zh ? "更多…" : "More..."}
              <ArrowRight />
            </a>
          </Button>
        </div>
      </section>

      <section id="plan" className="bg-[#eaf5f4] py-24">
        <div className="mx-auto max-w-7xl px-5 lg:px-8">
          <SectionHeading title={t.formTitle} text={t.formIntro} />
          <BookingForm lang={lang} config={config} />
        </div>
      </section>
      <section id="about" className="bg-[#153f3c] py-24 text-white">
        <div className="mx-auto grid max-w-7xl gap-12 px-5 lg:grid-cols-[1fr_.9fr] lg:items-center lg:px-8">
          <div>
            <p className="section-kicker !text-[#6fd0c8]">
              {zh ? "关于我们" : "ABOUT US"}
            </p>
            <h2 className="section-title !text-white">{t.whyTitle}</h2>
            <p className="mt-5 max-w-2xl text-lg leading-8 text-[#c2d8d5]">
              {t.whyIntro}
            </p>
            <div className="mt-8 grid gap-4 sm:grid-cols-2">
              {[
                [Clock3, zh ? "排期更可规划" : "More plannable scheduling"],
                [
                  CircleDollarSign,
                  zh ? "先了解费用范围" : "Pre-travel cost range",
                ],
                [Languages, zh ? "减少语言障碍" : "Bilingual coordination"],
                [MapPin, zh ? "治疗与住宿统一安排" : "Care and stay aligned"],
              ].map(([Icon, txt]) => (
                <div
                  className="flex items-center gap-3 rounded-2xl bg-white/7 p-4"
                  key={String(txt)}
                >
                  <Icon className="text-[#6fd0c8]" />
                  <b>{String(txt)}</b>
                </div>
              ))}
            </div>
            <div id="contact-info" className="mt-7 border-t border-white/15 pt-2 [&_a]:border-white/20 [&_a]:bg-white/10 [&_a]:text-white">
              <QuickContact content={config.content} />
            </div>
          </div>
          <Image
            unoptimized
            src="/arrival-care.png"
            alt={
              zh
                ? "国际患者抵达中国并获得接待"
                : "International dental patient welcomed in China"
            }
            width={1536}
            height={1024}
            className="h-[430px] rounded-[2.3rem] object-cover"
          />
        </div>
      </section>

      <section id="testimonials" className="bg-[#f7fbfb] py-24">
        <div className="mx-auto max-w-7xl px-5 lg:px-8">
          <SectionHeading
            title={zh ? "客户治疗旅程示例" : "Illustrative patient journeys"}
            text={
              zh
                ? "以下内容用于展示客户案例栏目结构，不代表已验证的比邻客户评价。正式推广前应替换为获得患者书面授权的真实案例。"
                : "These examples demonstrate the testimonial section structure and are not verified Be Neigh patient reviews. Replace them with consented, documented patient stories before promotion."
            }
          />
          <div className="mt-12 grid gap-5 md:grid-cols-3">
            {[
              [
                zh ? "多颗缺牙评估" : "Multiple missing teeth review",
                zh ? "演示案例" : "DEMO CASE",
                zh
                  ? "先提交CBCT和病史，比较分阶段种植方案、预计停留时间和复诊安排。"
                  : "Records and CBCT are reviewed first to compare staged implant options, expected stay and follow-up.",
              ],
              [
                zh ? "普通牙科集中治疗" : "General care during one visit",
                zh ? "演示案例" : "DEMO CASE",
                zh
                  ? "先确定治疗优先级，再把检查、洁牙和修复预约安排在一次赴华行程中。"
                  : "Treatment priorities are reviewed before coordinating examinations, cleaning and restorative appointments.",
              ],
              [
                zh ? "笑容美学方案沟通" : "Cosmetic smile planning",
                zh ? "演示案例" : "DEMO CASE",
                zh
                  ? "通过照片和影像初步沟通颜色、形态与咬合，再由牙医面诊确认适合的方案。"
                  : "Photos and scans support an early discussion of color, shape and bite before the dentist confirms suitability.",
              ],
            ].map(([title, label, text]) => (
              <article
                key={title}
                className="rounded-[1.8rem] bg-white p-7 shadow-sm"
              >
                <p className="text-sm font-bold tracking-[.12em] text-[#ec765f]">
                  {label}
                </p>
                <h3 className="mt-4 text-2xl font-bold">{title}</h3>
                <p className="mt-4 text-base leading-7 text-[#627b79]">
                  {text}
                </p>
              </article>
            ))}
          </div>
        </div>
      </section>

      <section id="faq" className="bg-white py-24">
        <div className="mx-auto max-w-4xl px-5">
          <SectionHeading title={t.faqTitle} />
          <div className="mt-10 divide-y divide-[#dcebea]">
            {faqItems.filter((x) => x.active !== false).sort((a,b) => Number(a.sortOrder)-Number(b.sortOrder)).map((item, i) => (
              <details className="group py-5" key={String(item.id || i)}>
                <summary className="flex cursor-pointer list-none items-center justify-between gap-5 text-lg font-bold">
                  {zh ? item.titleZh : item.titleEn}
                  <ChevronDown className="shrink-0 transition group-open:rotate-180" />
                </summary>
                <p className="max-w-3xl pt-4 leading-7 text-[#627b79]">
                  {zh ? item.textZh : item.textEn}
                </p>
              </details>
            ))}
          </div>
        </div>
      </section>
      {newsItems.some((x) => x.active !== false) && <section id="news" className="bg-[#f7fbfb] py-24"><div className="mx-auto max-w-7xl px-5 lg:px-8"><SectionHeading title={zh ? "新闻公告" : "News & Announcements"} /><div className="mt-10 grid gap-5 md:grid-cols-3">{newsItems.filter((x) => x.active !== false).sort((a,b) => String(b.date).localeCompare(String(a.date))).map((x,i) => <article key={String(x.id || i)} className="rounded-[1.6rem] bg-white p-6 shadow-sm"><p className="text-sm font-bold text-[#0f6d68]">{String(x.date || "")}</p><h3 className="mt-3 text-xl font-bold">{zh ? x.titleZh || x.titleEn : x.titleEn}</h3><p className="mt-3 leading-7 text-[#627b79]">{zh ? x.textZh || x.textEn : x.textEn}</p></article>)}</div></div></section>}
      <section id="contact" className="bg-[#edf7f6] py-24">
        <div className="mx-auto grid max-w-7xl gap-10 px-5 lg:grid-cols-[.85fr_1.15fr] lg:items-start lg:px-8">
          <div>
            <p className="section-kicker">{zh ? "联系我们" : "CONTACT US"}</p>
            <h2 className="section-title">
              {zh ? "先简单告诉我们您的问题" : "Ask a simple question"}
            </h2>
            <p className="mt-5 max-w-xl text-lg leading-8 text-[#627b79]">
              {zh
                ? "如果您暂时不准备填写完整预约资料，可先留下联系方式和问题，我们会安排人员回复。"
                : "Not ready to complete the full booking request? Leave your contact details and question, and our coordinator will reply."}
            </p>
          </div>
          <ContactForm lang={lang} />
        </div>
      </section>
      <SiteFooter lang={lang} email="info@beneigh.com" />
    </main>
  );
}
function SectionHeading({ title, text }: { title: string; text?: string }) {
  return (
    <div className="max-w-3xl">
      <p className="section-kicker">Be Neigh</p>
      <h2 className="section-title">{title}</h2>
      {text && <p className="mt-5 text-lg leading-8 text-[#627b79]">{text}</p>}
    </div>
  );
}
function Field({
  label,
  children,
}: {
  label: string;
  children: React.ReactNode;
}) {
  const id = useId();
  return (
    <div className="space-y-2">
      <Label htmlFor={id} className="text-base font-bold">
        {label}
      </Label>
      {isValidElement<{ id?: string }>(children)
        ? cloneElement(children, { id })
        : children}
    </div>
  );
}

function BookingForm({ lang, config }: { lang: Lang; config: SiteConfig }) {
  const zh = lang === "zh";
  const defaults: PublicService[] = defaultPlans;
  const options = (config.configured ? config.services : defaults)
    .filter((x) => x.active)
    .sort((a, b) => a.sortOrder - b.sortOrder);
  const [selected, setSelected] = useState(["implants"]),
    [sent, setSent] = useState<{
      reference: string;
      arrivalDate: string;
      returnDate: string;
      portalUrl: string;
      emailStatus: string;
    } | null>(null),
    [busy, setBusy] = useState(false),
    [error, setError] = useState("");
  useEffect(() => {
    setSelected((current) => {
      const valid = current.filter((id) => options.some((x) => x.id === id));
      return valid.length ? valid : options[0] ? [options[0].id] : [];
    });
  }, [config.services]);
  const payment = (() => {
      try {
        return JSON.parse(config.content.payment_settings || "{}") as Record<
          string,
          boolean
        >;
      } catch {
        return {};
      }
    })(),
    paymentNames = {
      wechat: "WeChat Pay",
      alipay: "Alipay",
      card: "Credit card",
      paypal: "PayPal",
    },
    planned = Object.entries(payment)
      .filter(([, on]) => on)
      .map(([id]) => paymentNames[id as keyof typeof paymentNames])
      .filter(Boolean);
  async function submit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setBusy(true);
    setError("");
    const fd = new FormData(e.currentTarget);
    const payload = {
      ...Object.fromEntries(fd.entries()),
      services: selected,
      language: lang,
    };
    try {
      const r = await fetch("/api/bookings", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify(payload),
      });
      const out = (await r.json()) as {
        reference: string;
        arrivalDate: string;
        returnDate: string;
        portalUrl: string;
        emailStatus: string;
        error?: string;
      };
      if (r.ok)
        setSent({
          reference: out.reference,
          arrivalDate: out.arrivalDate,
          returnDate: out.returnDate,
          portalUrl: out.portalUrl,
          emailStatus: out.emailStatus,
        });
      else setError(out.error || "Unable to submit");
    } catch {
      setError(
        "Unable to submit. Your entries are preserved; please try again.",
      );
    } finally {
      setBusy(false);
    }
  }
  if (sent)
    return (
      <div className="mt-10 rounded-[2rem] bg-white p-8 shadow-xl sm:p-12">
        <span className="grid size-16 place-items-center rounded-full bg-[#dff4ef] text-[#0f8b82]">
          <Check size={30} />
        </span>
        <h3 className="mt-5 text-3xl font-bold">
          {zh ? "预约提交成功" : "Booking submitted"}
        </h3>
        <p className="mt-3 text-[#627b79]">
          {zh
            ? "请保存预约编号。邮件发送将在正式发信域名配置后自动启用。"
            : "Save your booking reference. Keep your private portal link to read and reply to messages."}
        </p>
        <div className="mt-7 grid gap-4 rounded-2xl bg-[#f3f9f8] p-5 sm:grid-cols-3">
          <Info k={zh ? "预约编号" : "Reference"} v={sent.reference} />
          <Info k={zh ? "抵达日期" : "Arrival"} v={sent.arrivalDate} />
          <Info k={zh ? "返程日期" : "Return"} v={sent.returnDate} />
        </div>
        <Button className="mt-7 min-h-12 rounded-full" asChild>
          <a href={sent.portalUrl}>Open Client Portal</a>
        </Button>
        <p className="mt-4 break-all text-sm">Private link: {sent.portalUrl}</p>
        <p className="mt-3 text-sm">
          Email:{" "}
          {sent.emailStatus === "sent"
            ? "Sent"
            : "Not sent — email service needs configuration."}
        </p>
        <Button className="mt-7 rounded-full" onClick={() => setSent(null)}>
          {zh ? "提交另一份预约" : "Make another booking"}
        </Button>
      </div>
    );
  return (
    <>
      <form onSubmit={submit} className="mt-8">
        <div className="rounded-[2rem] bg-white p-6 shadow-xl sm:p-8">
          <h3 className="text-xl font-bold">1. Choose Your Plans</h3>
          <div className="mt-5 grid gap-3 sm:grid-cols-2">
            {options.map((option) => (
              <label
                key={option.id}
                className={`cursor-pointer overflow-hidden rounded-2xl border active:scale-[.99] ${selected.includes(option.id) ? "border-[#0f8b82] bg-[#ecf8f6]" : "hover:border-[#9bcac6]"}`}
              >
                <div className="p-4">
                  <Checkbox
                    checked={selected.includes(option.id)}
                    onCheckedChange={(v) =>
                      setSelected(
                        v
                          ? [...new Set([...selected, option.id])]
                          : selected.filter((x) => x !== option.id),
                      )
                    }
                  />
                  <b className="mt-3 block">
                    {zh ? option.nameZh : option.nameEn}
                  </b>
                </div>
              </label>
            ))}
          </div>
          <h3 className="mt-9 text-xl font-bold">
            2. {zh ? "个人资料" : "Personal details"}
          </h3>
          <div className="mt-5 grid gap-5 sm:grid-cols-2">
            <Field label={zh ? "称谓" : "Title"}>
              <select name="title" required className="min-h-11 w-full rounded-md border px-3">
                <option value="">{zh ? "请选择" : "Select"}</option>
                <option>Mr</option><option>Ms</option><option>Mrs</option>
              </select>
            </Field>
            <Field label={zh ? "姓名" : "Full name"}>
              <Input name="name" required minLength={2} />
            </Field>
            <Field label={zh ? "电子邮箱" : "Email"}>
              <Input name="email" type="email" required />
            </Field>
            <Field label={zh ? "国家" : "Country"}>
              <Input name="country" required />
            </Field>
            <Field label={zh ? "地区/城市" : "Region / City"}>
              <Input name="region" required />
            </Field>
            <Field label={zh ? "预计抵达日期" : "Expected Arrival Date"}>
              <Input name="arrivalDate" type="date" min={new Date().toISOString().slice(0,10)} required />
            </Field>
            <Field label={zh ? "预计返程日期" : "Expected Return Date"}>
              <Input name="returnDate" type="date" min={new Date().toISOString().slice(0,10)} required />
            </Field>
            <div className="sm:col-span-2">
              <Field label={zh ? "备注（选填）" : "Notes (optional)"}>
                <Textarea name="notes" rows={5} />
              </Field>
            </div>
          </div>
          {error && <p className="mt-4 font-bold text-red-600">{error}</p>}
          <div className="mt-7 rounded-2xl bg-[#153f3c] p-5 text-white">
            <b>{zh ? "下一步" : "What Happens Next"}</b>
            <p className="mt-2 text-sm leading-6 text-[#c5dcda]">{zh ? "我们会通过邮件联系您，并在资料审核后提供详细报价。提交申请不代表已确认临床预约。" : "We will contact you by email and provide a detailed quotation after reviewing your request. Submission does not confirm a clinical appointment."}</p>
          {planned.length > 0 && (
            <div className="mt-4 rounded-xl bg-white/8 p-3 text-xs leading-5 text-[#c5dcda]">
              <b className="block text-white">
                {zh ? "预留支付方式" : "Reserved payment methods"}
              </b>
              {planned.join(" · ")}
              <br />
              {zh
                ? "实际收款将在双方确认后启用。"
                : "Collection is enabled only after confirmation."}
            </div>
          )}
          <Button disabled={busy || !selected.length} className="mt-6 h-13 rounded-full bg-[#ec765f] px-8 text-white hover:bg-[#d85e49] active:scale-[.98]">
            {busy
              ? zh
                ? "提交中…"
                : "Submitting…"
              : zh
                ? "提交预约"
                : "Submit booking"}
            <ArrowRight />
          </Button></div>
        </div>
      </form>
    </>
  );
}
function Info({ k, v }: { k: string; v: string }) {
  return (
    <div>
      <p className="text-xs font-bold text-[#78908e]">{k}</p>
      <p className="mt-1 font-bold">{v}</p>
    </div>
  );
}
