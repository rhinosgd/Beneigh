"use client";
import { useEffect, useRef, useState } from "react";
import { Button } from "@/components/ui/button";
import { cleanRichHtml, RichContent } from "./rich-content";
export function RichEditor({
  value,
  onChange,
}: {
  value: string;
  onChange: (html: string) => void;
}) {
  const editor = useRef<HTMLDivElement>(null),
    selection = useRef<Range | null>(null),
    [size, setSize] = useState(16);
  useEffect(() => {
    if (editor.current) editor.current.innerHTML = cleanRichHtml(value);
  }, []);
  function save() {
    if (editor.current) onChange(cleanRichHtml(editor.current.innerHTML));
  }
  function rememberSelection() {
    const current = window.getSelection();
    if (current?.rangeCount && editor.current?.contains(current.anchorNode))
      selection.current = current.getRangeAt(0).cloneRange();
  }
  function command(name: string, argument?: string) {
    editor.current?.focus();
    if (selection.current) {
      const current = window.getSelection();
      current?.removeAllRanges();
      current?.addRange(selection.current);
    }
    document.execCommand(name, false, argument);
    rememberSelection();
    save();
  }
  return (
    <div>
      <div className="mt-4 flex flex-wrap items-center gap-3">
        {["bold", "italic", "underline"].map((name) => (
          <Button
            type="button"
            key={name}
            variant="outline"
            className="min-h-11"
            onMouseDown={(e) => e.preventDefault()}
            onClick={() => command(name)}
          >
            {name}
          </Button>
        ))}
        <select
          aria-label="Font family"
          className="min-h-11 rounded-lg border px-2"
          onChange={(e) => command("fontName", e.target.value)}
        >
          <option>Arial</option>
          <option>Georgia</option>
          <option>Verdana</option>
          <option>Times New Roman</option>
        </select>
        <label className="flex items-center gap-2 text-sm">
          Size
          <input
            aria-label="Font size 16 to 48 px"
            type="number"
            min={16}
            max={48}
            value={size}
            onChange={(e) =>
              setSize(Math.min(48, Math.max(16, Number(e.target.value))))
            }
            className="h-11 w-16 rounded-lg border px-2"
          />
          <Button
            type="button"
            variant="outline"
            className="min-h-11"
            onMouseDown={(e) => e.preventDefault()}
            onClick={() => {
              command("fontSize", "7");
              editor.current
                ?.querySelectorAll('font[size="7"]')
                .forEach((n) => {
                  (n as HTMLElement).style.fontSize = `${size}px`;
                  n.removeAttribute("size");
                });
              save();
            }}
          >
            Apply Size
          </Button>
        </label>
        <label className="flex items-center gap-2 text-sm">
          Color
          <input
            aria-label="Font color"
            type="color"
            onChange={(e) => command("foreColor", e.target.value)}
          />
        </label>
      </div>
      <div
        ref={editor}
        contentEditable
        suppressContentEditableWarning
        onInput={save}
        onBlur={rememberSelection}
        onKeyUp={rememberSelection}
        onMouseUp={rememberSelection}
        className="mt-4 min-h-40 rounded-xl border bg-white p-4 text-base"
      />
      <div className="mt-4 rounded-xl bg-[#f2f7f7] p-4">
        <p className="mb-3 text-sm font-bold">保存效果预览</p>
        <RichContent html={value} />
      </div>
    </div>
  );
}
