"use client";
import { useEffect, useState } from "react";
export function cleanRichHtml(html: string) {
  if (typeof DOMParser === "undefined") return "";
  const source = new DOMParser().parseFromString(html, "text/html"),
    target = document.createElement("div"),
    allowed = new Set([
      "P",
      "BR",
      "DIV",
      "SPAN",
      "B",
      "STRONG",
      "I",
      "EM",
      "U",
      "UL",
      "OL",
      "LI",
      "FONT",
    ]);
  function copy(node: Node, parent: Node) {
    if (node.nodeType === 3) {
      parent.appendChild(document.createTextNode(node.textContent || ""));
      return;
    }
    if (!(node instanceof Element)) return;
    if (!allowed.has(node.tagName)) {
      if (
        ["SCRIPT", "STYLE", "IFRAME", "OBJECT", "SVG", "MATH"].includes(
          node.tagName,
        )
      )
        return;
      for (const child of Array.from(node.childNodes)) copy(child, parent);
      return;
    }
    const out = document.createElement(
      node.tagName === "FONT" ? "span" : node.tagName.toLowerCase(),
    );
    const style = (node as HTMLElement).style;
    if (style) {
      for (const key of [
        "color",
        "fontFamily",
        "fontSize",
        "fontWeight",
        "fontStyle",
        "textDecoration",
      ] as const) {
        const value = style[key];
        if (value && !/url|expression|@|[<>]/i.test(value))
          out.style[key] = value;
      }
    }
    const color = node.getAttribute("color"),
      face = node.getAttribute("face");
    if (color && /^#[a-f0-9]{3,8}$/i.test(color)) out.style.color = color;
    if (face && /^[a-z ,'-]{1,80}$/i.test(face)) out.style.fontFamily = face;
    for (const child of Array.from(node.childNodes)) copy(child, out);
    parent.appendChild(out);
  }
  for (const n of Array.from(source.body.childNodes)) copy(n, target);
  return target.innerHTML;
}
export function RichContent({ html }: { html: string }) {
  const [safe, setSafe] = useState("");
  useEffect(() => setSafe(cleanRichHtml(html)), [html]);
  return (
    <div
      className="text-base leading-8"
      dangerouslySetInnerHTML={{ __html: safe }}
    />
  );
}
