import { ArrowRight } from "lucide-react";
import { BeneighLogo, type SiteLang } from "./site-header";

export function SiteFooter({
  lang,
  email,
}: {
  lang: SiteLang;
  email?: string;
}) {
  const zh = lang === "zh";
  return (
    <footer className="bg-[#0e2f2d] px-5 py-14 text-white">
      <div className="mx-auto grid max-w-7xl gap-10 lg:grid-cols-[1.2fr_.8fr_.8fr]">
        <div>
          <div className="[&_*]:!text-white">
            <BeneighLogo />
          </div>
          <p className="mt-5 max-w-md text-base leading-7 text-[#aac6c3]">
            {zh
              ? "为国际患者提供赴华牙科治疗信息、诊所匹配与行程协调服务。诊断和治疗由独立持证牙科专业人员提供。"
              : "Information, clinic matching and travel coordination for international patients seeking dental care in China. Diagnosis and treatment are provided by independently licensed dental professionals."}
          </p>
        </div>
        <div>
          <b className="text-lg">{zh ? "服务项目" : "Services"}</b>
          <div className="mt-4 space-y-3 text-[#aac6c3]">
            <a className="block" href="/services/dental-implants">
              Dental Implants
            </a>
            <a className="block" href="/services/general-dentistry">
              General Dentistry
            </a>
            <a className="block" href="/services/cosmetic-dentistry">
              Cosmetic Dentistry
            </a>
          </div>
        </div>
        <div>
          <b className="text-lg">{zh ? "开始咨询" : "Start here"}</b>
          <a
            href="/#contact"
            className="mt-4 flex items-center gap-2 text-[#7ed7cf]"
          >
            {zh ? "提交简单询问" : "Send an inquiry"}
            <ArrowRight size={17} />
          </a>
          {email && (
            <a
              className="mt-4 block text-sm text-[#aac6c3]"
              href={`mailto:${email}`}
            >
              {email}
            </a>
          )}
          <p className="mt-8 text-sm text-[#779a97]">tochinadental.com</p>
        </div>
      </div>
      <div className="mx-auto mt-12 max-w-7xl border-t border-white/10 pt-6 text-sm text-[#779a97]">
        © 2026 Be Neigh.{" "}
        {zh
          ? "网站内容不构成医疗建议。"
          : "Website content is not medical advice."}
      </div>
    </footer>
  );
}
