"use client";

import { ChevronDown, Globe2, Menu, X } from "lucide-react";
import { useState } from "react";

export type SiteLang = "en" | "zh" | "ja" | "ko" | "pt" | "es" | "fr" | "ar";
const nav = [
  { en: "Home", zh: "主页", href: "/#top" },
  { en: "Services", zh: "服务项目", href: "/#services", services: true },
  { en: "Pricing", zh: "价格", href: "/#pricing" },
  { en: "How It Works", zh: "流程", href: "/#services-flow" },
  { en: "Testimonials", zh: "客户案例", href: "/#testimonials" },
  { en: "FAQ", zh: "常见问题", href: "/#faq" },
  { en: "Contact Us", zh: "联系我们", href: "/#contact" },
];
const serviceLinks = [
  { en: "Dental Implants", zh: "种植牙", href: "/services/dental-implants" },
  {
    en: "General Dentistry",
    zh: "普通牙科",
    href: "/services/general-dentistry",
  },
  {
    en: "Cosmetic Dentistry",
    zh: "牙科美容",
    href: "/services/cosmetic-dentistry",
  },
];

export function BeneighLogo() {
  return (
    <span className="flex items-center gap-3">
      <span className="grid size-11 place-items-center rounded-[15px] bg-[#0f6d68] font-serif text-lg font-black tracking-[-.18em] text-white shadow-sm" aria-hidden="true">
        比邻
      </span>
      <span className="leading-none">
        <b className="block text-xl tracking-[-.02em]">Be Neighbor</b>
        <small className="mt-1 hidden text-[12px] sm:block font-semibold tracking-[.16em] text-[#ec765f]">
          Medi Care In China
        </small>
      </span>
    </span>
  );
}

function BilingualLabel({ en, zh }: { en: string; zh: string }) {
  return (
    <span className="flex flex-col leading-tight">
      <b className="text-base">{en}</b>
    </span>
  );
}

export function SiteHeader({
  lang,
  onLanguageChange,
}: {
  lang: SiteLang;
  onLanguageChange: (lang: SiteLang) => void;
}) {
  const [open, setOpen] = useState(false);
  return (
    <header className="fixed inset-x-0 top-0 z-50 border-b border-[#dcebea]/90 bg-[#f7fbfb]/95 backdrop-blur-xl">
      <div className="mx-auto flex h-20 max-w-[1440px] items-center justify-between px-4 xl:px-7">
        <a href="/#top" aria-label="Be Neighbor home">
          <BeneighLogo />
        </a>
        <nav className="hidden items-center gap-4 xl:flex">
          {nav.map((item) =>
            item.services ? (
              <div className="group relative" key={item.en}>
                <a
                  href={item.href}
                  className="flex items-center gap-1 py-6 text-[#294f4c] hover:text-[#ec765f]"
                >
                  <BilingualLabel en={item.en} zh={item.zh} />
                  <ChevronDown size={15} />
                </a>
                <div className="invisible absolute left-1/2 top-full w-80 -translate-x-1/2 rounded-2xl border border-[#dcebea] bg-white p-2 opacity-0 shadow-2xl transition group-hover:visible group-hover:opacity-100 group-focus-within:visible group-focus-within:opacity-100">
                  {serviceLinks.map((link) => (
                    <a
                      key={link.en}
                      href={link.href}
                      className="flex items-center justify-between rounded-xl px-4 py-3 hover:bg-[#edf7f6]"
                    >
                      <BilingualLabel en={link.en} zh={link.zh} />
                      <span aria-hidden="true">›</span>
                    </a>
                  ))}
                </div>
              </div>
            ) : (
              <a
                key={item.en}
                href={item.href}
                className="text-[#294f4c] hover:text-[#ec765f]"
              >
                <BilingualLabel en={item.en} zh={item.zh} />
              </a>
            ),
          )}
        </nav>
        <div className="flex items-center gap-2">
          <a
            href="/client-portal"
            className="inline-flex min-h-11 items-center rounded-full bg-[#0f6d68] px-3 text-sm font-bold text-white hover:bg-[#0b504c] active:scale-95"
          >
            <span className="hidden sm:inline">Client&nbsp;</span>Login
          </a>
          <select
            aria-label="Language"
            value={lang}
            onChange={(e) => {
              const value = e.target.value as SiteLang;
              localStorage.setItem("beneigh_language", value);
              onLanguageChange(value);
            }}
            className="min-h-11 max-w-24 sm:max-w-28 rounded-full border bg-white px-2 text-sm font-bold"
          >
            <option value="en">English</option>
            <option value="zh">中文</option>
            <option value="ja">日本語</option>
            <option value="ko">한국어</option>
            <option value="pt">Português</option>
            <option value="es">Español</option>
            <option value="fr">Français</option>
            <option value="ar">العربية</option>
          </select>
          <button
            aria-label="Open navigation"
            className="grid size-11 place-items-center rounded-full bg-white xl:hidden"
            onClick={() => setOpen(!open)}
          >
            {open ? <X /> : <Menu />}
          </button>
        </div>
      </div>
      {open && (
        <nav className="max-h-[calc(100vh-5rem)] overflow-y-auto border-t bg-[#f7fbfb] px-5 pb-5 xl:hidden">
          {nav.map((item) =>
            item.services ? (
              <details key={item.en} className="group border-b">
                <summary className="flex cursor-pointer list-none items-center justify-between py-4">
                  <BilingualLabel en={item.en} zh={item.zh} />
                  <ChevronDown className="transition group-open:rotate-180" />
                </summary>
                <div className="pb-3">
                  {serviceLinks.map((link) => (
                    <a
                      onClick={() => setOpen(false)}
                      key={link.en}
                      href={link.href}
                      className="flex items-center justify-between border-t border-[#e4efee] py-3 pl-3"
                    >
                      <BilingualLabel en={link.en} zh={link.zh} />
                      <span aria-hidden="true">›</span>
                    </a>
                  ))}
                </div>
              </details>
            ) : (
              <a
                onClick={() => setOpen(false)}
                key={item.en}
                href={item.href}
                className="block border-b py-4"
              >
                <BilingualLabel en={item.en} zh={item.zh} />
              </a>
            ),
          )}
          <select
            aria-label="Language"
            value={lang}
            onChange={(e) => {
              const value = e.target.value as SiteLang;
              localStorage.setItem("beneigh_language", value);
              onLanguageChange(value);
            }}
            className="min-h-11 max-w-28 rounded-full border bg-white px-2 text-sm font-bold"
          >
            <option value="en">English</option>
            <option value="zh">中文</option>
            <option value="ja">日本語</option>
            <option value="ko">한국어</option>
            <option value="pt">Português</option>
            <option value="es">Español</option>
            <option value="fr">Français</option>
            <option value="ar">العربية</option>
          </select>
        </nav>
      )}
    </header>
  );
}
