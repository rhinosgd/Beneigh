import { env } from "cloudflare:workers";

type StoredObject = {
  body: ReadableStream;
  httpMetadata?: { contentType?: string };
  etag?: string;
};
type Bucket = { get(key: string): Promise<StoredObject | null> };

export async function GET(request: Request) {
  const key = new URL(request.url).searchParams.get("key") || "";
  if (!key.startsWith("site-media/") || key.includes(".."))
    return new Response("Not found", { status: 404 });
  const bucket = (env as unknown as { BUCKET: Bucket }).BUCKET;
  if (!bucket) return new Response("Unavailable", { status: 503 });
  const object = await bucket.get(key);
  if (!object) return new Response("Not found", { status: 404 });
  return new Response(object.body, {
    headers: {
      "content-type":
        object.httpMetadata?.contentType || "application/octet-stream",
      "cache-control": "public, max-age=31536000, immutable",
      ...(object.etag ? { etag: object.etag } : {}),
    },
  });
}
