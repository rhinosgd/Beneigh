import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Be Neighbor | Medi Care In China",
  description: "Bilingual dental treatment planning, clinic matching, appointments and travel coordination for international patients visiting China.",
  other: {
    "codex-preview": "development",
  },
  icons: {
    icon: "/favicon.svg",
    shortcut: "/favicon.svg",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <body className="antialiased">{children}</body>
    </html>
  );
}
