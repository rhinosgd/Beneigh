$ErrorActionPreference = "Stop"
$projectRoot = Split-Path -Parent $PSScriptRoot
Set-Location $projectRoot
try {
  Start-Transcript -Path "$projectRoot\Beneigh-startup.log" -Append | Out-Null
} catch {}

function Stop-WithMessage([string]$message) {
  Write-Host ""
  Write-Host $message -ForegroundColor Red
  Read-Host "按 Enter 关闭"
  exit 1
}

Write-Host "==============================================" -ForegroundColor Cyan
Write-Host "  Beneigh 本地网站 + Cloudflare 公网预览" -ForegroundColor Cyan
Write-Host "==============================================" -ForegroundColor Cyan

if (-not (Get-Command node.exe -ErrorAction SilentlyContinue)) {
  Write-Host "未检测到 Node.js，正在自动安装 Node.js LTS……" -ForegroundColor Yellow
  $winget = Get-Command winget.exe -ErrorAction SilentlyContinue
  if (-not $winget) {
    Start-Process "https://nodejs.org/en/download"
    Stop-WithMessage "这台电脑没有 Windows 应用安装器，已打开 Node.js 下载页。安装 LTS 版本后重新双击启动文件。"
  }

  & winget.exe install --id OpenJS.NodeJS.LTS --exact --silent --accept-package-agreements --accept-source-agreements
  if ($LASTEXITCODE -ne 0) {
    Stop-WithMessage "Node.js 自动安装未完成。请允许 Windows 安装提示，或先手动安装 Node.js LTS。"
  }

  $machinePath = [Environment]::GetEnvironmentVariable("Path", "Machine")
  $userPath = [Environment]::GetEnvironmentVariable("Path", "User")
  $env:Path = "$machinePath;$userPath"
  if (-not (Get-Command node.exe -ErrorAction SilentlyContinue)) {
    Stop-WithMessage "Node.js 已安装，但 Windows 尚未刷新环境。请重新打开本文件即可继续。"
  }
  Write-Host "Node.js LTS 安装完成。" -ForegroundColor Green
}

if (-not (Test-Path "$projectRoot\node_modules\.bin\vite.cmd")) {
  Write-Host "首次运行：正在安装网站运行组件，可能需要几分钟……" -ForegroundColor Yellow
  & npm.cmd install
  if ($LASTEXITCODE -ne 0) { Stop-WithMessage "运行组件安装失败。请检查网络后重试。" }
}

if (-not (Test-Path "$projectRoot\.dev.vars")) {
  $ownerPassword = "BeN-" + ([guid]::NewGuid().ToString("N").Substring(0,16)) + "!9a"
  $staffPassword = "Staff-" + ([guid]::NewGuid().ToString("N").Substring(0,14)) + "!8b"
  $sessionSecret = [guid]::NewGuid().ToString("N") + [guid]::NewGuid().ToString("N")
  @"
ADMIN_USERNAME=beneigh_admin
ADMIN_PASSWORD=$ownerPassword
SESSION_SECRET=$sessionSecret
STAFF_USERNAME=beneigh_staff
STAFF_PASSWORD=$staffPassword
RESEND_API_KEY=
EMAIL_FROM=
"@ | Set-Content -Path "$projectRoot\.dev.vars" -Encoding UTF8
  @"
Beneigh 本地预览管理账号

管理端：http://127.0.0.1:8767/manage-portal-7x
管理员账号：beneigh_admin
管理员密码：$ownerPassword

客服账号：beneigh_staff
客服密码：$staffPassword

请勿把管理员密码发给不可信人员。
"@ | Set-Content -Path "$projectRoot\本地预览账号.txt" -Encoding UTF8
  Write-Host "已生成本地预览账号：本地预览账号.txt" -ForegroundColor Green
}

Write-Host "正在初始化本地数据库……" -ForegroundColor Yellow
"y" | & npx.cmd wrangler d1 migrations apply DB --local --config wrangler.local.jsonc
if ($LASTEXITCODE -ne 0) {
  Write-Host "检测到旧版本地数据库，正在保留备份并重建演示数据库……" -ForegroundColor Yellow
  if (Test-Path "$projectRoot\.wrangler\state") {
    $backupName = "state-backup-" + (Get-Date -Format "yyyyMMdd-HHmmss")
    Move-Item "$projectRoot\.wrangler\state" "$projectRoot\.wrangler\$backupName"
  }
  "y" | & npx.cmd wrangler d1 migrations apply DB --local --config wrangler.local.jsonc
  if ($LASTEXITCODE -ne 0) { Stop-WithMessage "本地数据库初始化失败。" }
}

$serverCommand = "title Beneigh Local Website && cd /d `"$projectRoot`" && npx vite --host 127.0.0.1 --port 8767 --strictPort"
$server = Start-Process -FilePath "cmd.exe" -ArgumentList "/k", $serverCommand -PassThru

Write-Host "正在启动 Beneigh 网站……" -ForegroundColor Yellow
$ready = $false
for ($attempt = 0; $attempt -lt 60; $attempt++) {
  Start-Sleep -Seconds 1
  try {
    $response = Invoke-WebRequest -Uri "http://127.0.0.1:8767/review" -UseBasicParsing -TimeoutSec 2
    if ($response.StatusCode -ge 200 -and $response.StatusCode -lt 400) { $ready = $true; break }
  } catch {}
}

if (-not $ready) {
  & taskkill.exe /PID $server.Id /T /F 2>$null | Out-Null
  Stop-WithMessage "Beneigh 网站未能在8767端口启动。请检查是否有其他程序占用该端口。"
}

Start-Process "http://127.0.0.1:8767/review"
Write-Host "本地网站已启动：http://127.0.0.1:8767/review" -ForegroundColor Green

$cloudflared = "$projectRoot\cloudflared.exe"
if (-not (Test-Path $cloudflared)) {
  Write-Host "首次运行：正在下载 Cloudflare 临时隧道工具……" -ForegroundColor Yellow
  Invoke-WebRequest -Uri "https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-windows-amd64.exe" -OutFile $cloudflared -UseBasicParsing
}

Write-Host ""
Write-Host "正在创建公网地址，请稍候……" -ForegroundColor Yellow
Write-Host "看到绿色网址后，把该网址发给客户即可。关闭本窗口会停止公网访问。" -ForegroundColor Yellow
$opened = $false

try {
  & $cloudflared tunnel --url http://127.0.0.1:8767 2>&1 | ForEach-Object {
    $line = $_.ToString()
    Write-Host $line
    if (-not $opened -and $line -match "https://[a-z0-9-]+\.trycloudflare\.com") {
      $publicUrl = $matches[0] + "/review"
      $publicUrl | Set-Content -Path "$projectRoot\公网预览网址.txt" -Encoding UTF8
      Write-Host ""
      Write-Host "客户公网预览网址：$publicUrl" -ForegroundColor Green
      Write-Host "网址已保存到：公网预览网址.txt" -ForegroundColor Green
      Start-Process $publicUrl
      $opened = $true
    }
  }
} finally {
  & taskkill.exe /PID $server.Id /T /F 2>$null | Out-Null
}
